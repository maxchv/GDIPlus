﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace UserControls
{
    public class SuperButton : Button
    {
        public static readonly int MIN_SIDES = 3;
        public static readonly int MAX_SIDES = 20;
        public static readonly string DefaultBack = "Gold";
        public static readonly string DefaultFore = "Black";
        public static readonly string DefaultHover = "Wheat";
        public static readonly string DefaultClick = "DarkOrange";
        private Color backColor = Color.Gold;
        private Color foreColor = Color.Black;

        private Color oldBackColor = Color.Gold;
        private int sides = MIN_SIDES;
        private string text;

        public bool Endered { get; set; }

        [DefaultValue(3)]
        [TypeConverter(typeof(SidesConverter))] //что-бы в дизайнере нельзя было задать неверное кол-во сторон 
        public int Sides
        {
            get => sides;
            set
            {
                if (value >= MIN_SIDES)
                {
                    sides = value;
                }
                else if (value <= MAX_SIDES)
                {
                    sides = value;
                }

                Invalidate();
            }
        }

        public override Color BackColor
        {
            get => backColor;
            set
            {
                backColor = value;
                Invalidate();
            }
        }

        public override Color ForeColor
        {
            get => foreColor;
            set
            {
                foreColor = value;
                Invalidate();
            }
        }

        public override string Text
        {
            get => text;
            set
            {
                text = value;
                Invalidate();
            }
        }

        public Color OnClkColor { get; set; } = Color.Wheat;
        public Color OnHoverColor { get; set; } = Color.LightSkyBlue;

        protected override void OnPaint(PaintEventArgs pevent)
        {
            Graphics g = pevent.Graphics;

            var path = new GraphicsPath();
            var pt = new PointF(ClientRectangle.X + ClientRectangle.Width / 2f,
                ClientRectangle.Y + ClientRectangle.Height / 2f);
            var r = Math.Min(ClientRectangle.Height, ClientRectangle.Width) / 2f;

            var points = new PointF[Sides];
            for (int i = 0; i < points.Length; i++)
            {
                points[i] = new PointF(pt.X + r * (float) Math.Cos(2 * Math.PI * i / Sides),
                    pt.Y + r * (float) Math.Sin(2 * Math.PI * i / Sides));
            }

            path.AddPolygon(points);
            Region = new Region(path); //для региона не нужно вычислять "пустые области"
            g.FillRegion(new SolidBrush(BackColor), Region);

            StringFormat fmt = new StringFormat();
            fmt.Alignment = StringAlignment.Center;
            fmt.LineAlignment = StringAlignment.Center;
            g.DrawString(Text, Font, new SolidBrush(ForeColor), ClientRectangle, fmt);
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            base.OnMouseEnter(e);
            oldBackColor = BackColor;
            BackColor = OnHoverColor;
            Endered = true;
            Invalidate();
        }

        protected override void OnMouseDown(MouseEventArgs mevent)
        {
            base.OnMouseDown(mevent);
            if (mevent.Button == MouseButtons.Left)
            {
                BackColor = OnClkColor;
                Invalidate();
            }
        }

        protected override void OnMouseUp(MouseEventArgs mevent)
        {
            base.OnMouseUp(mevent);
            if (mevent.Button == MouseButtons.Left)
            {
                BackColor = Endered ? OnHoverColor : OnClkColor;
                Invalidate();
            }
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            BackColor = oldBackColor;
            Endered = false;
            Invalidate();
        }
    }
}