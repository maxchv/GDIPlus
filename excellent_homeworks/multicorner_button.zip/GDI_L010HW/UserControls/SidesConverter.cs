﻿using System;
using System.ComponentModel;
using System.Globalization;

namespace UserControls
{
    internal class SidesConverter : TypeConverter
    {
        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
        {
            return sourceType == typeof(string) || base.CanConvertFrom(context, sourceType);
        }

        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            if (!(value is string))
            {
                return base.ConvertFrom(context, culture, value);
            }

            var result = 3;
            try
            {
                result = Convert.ToInt32(value);
            }
            catch (FormatException ex)
            {
                throw new FormatException($"Значение {value} недопустимо");
            }

            if (result < SuperButton.MIN_SIDES)
            {
                throw new FormatException($"Значение должно быть больше {SuperButton.MIN_SIDES}");
            }

            if (result > SuperButton.MAX_SIDES)
            {
                throw new FormatException($"Значение должно быть меньше {SuperButton.MAX_SIDES}");
            }

            return result;
        }
    }
}