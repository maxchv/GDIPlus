﻿using System;
using System.Drawing;
using System.Windows.Forms;
using UserControls;

namespace GDI_L010HW
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            Sides_UpDown.Minimum = SuperButton.MIN_SIDES;
            Sides_UpDown.Maximum = SuperButton.MAX_SIDES;
            Sides_UpDown.Increment = 1;

            //var colors = typeof(KnownColor).GetEnumNames();

            BackColor_ComboBox.DataSource = typeof(KnownColor).GetEnumNames();
            Text_ComboBox.DataSource = typeof(KnownColor).GetEnumNames();
            HoverColor_ComboBox.DataSource = typeof(KnownColor).GetEnumNames();
            ClickColor_ComboBox.DataSource = typeof(KnownColor).GetEnumNames();

            Reset();
        }

        private void SuperButton1_Click(object sender, EventArgs e)
        {}

        private void Sides_UpDown_ValueChanged(object sender, EventArgs e)
        {
            superButton1.Sides = (int) Sides_UpDown.Value;
        }

        private void Colors_ComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            var sen = sender as ComboBox;
            if (sen.SelectedIndex != -1)
            {
                switch ((Colors) Enum.Parse(typeof(Colors), sen.Tag.ToString()))
                {
                    case Colors.Background:
                        superButton1.BackColor =
                            Color.FromKnownColor((KnownColor) Enum.Parse(typeof(KnownColor), sen.Text));
                        break;
                    case Colors.Foreground:
                        superButton1.ForeColor =
                            Color.FromKnownColor((KnownColor) Enum.Parse(typeof(KnownColor), sen.Text));
                        break;
                    case Colors.Hover:
                        superButton1.OnHoverColor =
                            Color.FromKnownColor((KnownColor) Enum.Parse(typeof(KnownColor), sen.Text));
                        break;
                    case Colors.Click:
                        superButton1.OnClkColor =
                            Color.FromKnownColor((KnownColor) Enum.Parse(typeof(KnownColor), sen.Text));
                        break;
                }
            }
        }

        private void ButtonText_TextBox_TextChanged(object sender, EventArgs e)
        {
            superButton1.Text = (sender as TextBox).Text;
        }

        private void Reset_Button_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void Reset()
        {
            Sides_UpDown.Value = 3m;
            BackColor_ComboBox.SelectedItem = SuperButton.DefaultBack;
            Text_ComboBox.SelectedItem = SuperButton.DefaultFore;
            HoverColor_ComboBox.SelectedItem = SuperButton.DefaultHover;
            ClickColor_ComboBox.SelectedItem = SuperButton.DefaultClick;
            ButtonText_TextBox.Text = superButton1.Name;
        }
    }
}