﻿namespace GDI_L010HW
{
    public enum Colors
    {
        Background,
        Foreground,
        Hover,
        Click
    }
}