﻿namespace GDI_L010HW
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.Sides_UpDown = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.BackColor_ComboBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ButtonText_TextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Text_ComboBox = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ClickColor_ComboBox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.HoverColor_ComboBox = new System.Windows.Forms.ComboBox();
            this.Reset_Button = new System.Windows.Forms.Button();
            this.superButton1 = new UserControls.SuperButton();
            ((System.ComponentModel.ISupportInitialize)(this.Sides_UpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // Sides_UpDown
            // 
            this.Sides_UpDown.Location = new System.Drawing.Point(288, 12);
            this.Sides_UpDown.Name = "Sides_UpDown";
            this.Sides_UpDown.Size = new System.Drawing.Size(120, 20);
            this.Sides_UpDown.TabIndex = 1;
            this.Sides_UpDown.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.Sides_UpDown.ValueChanged += new System.EventHandler(this.Sides_UpDown_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(249, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sides";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BackColor_ComboBox
            // 
            this.BackColor_ComboBox.FormattingEnabled = true;
            this.BackColor_ComboBox.Location = new System.Drawing.Point(288, 38);
            this.BackColor_ComboBox.Name = "BackColor_ComboBox";
            this.BackColor_ComboBox.Size = new System.Drawing.Size(121, 21);
            this.BackColor_ComboBox.TabIndex = 3;
            this.BackColor_ComboBox.Tag = "Background";
            this.BackColor_ComboBox.SelectedIndexChanged += new System.EventHandler(this.Colors_ComboBox_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(220, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Button color";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ButtonText_TextBox
            // 
            this.ButtonText_TextBox.Location = new System.Drawing.Point(288, 146);
            this.ButtonText_TextBox.Name = "ButtonText_TextBox";
            this.ButtonText_TextBox.Size = new System.Drawing.Size(121, 20);
            this.ButtonText_TextBox.TabIndex = 4;
            this.ButtonText_TextBox.TextChanged += new System.EventHandler(this.ButtonText_TextBox_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(254, 149);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Text";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(228, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Text color";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Text_ComboBox
            // 
            this.Text_ComboBox.FormattingEnabled = true;
            this.Text_ComboBox.Location = new System.Drawing.Point(288, 65);
            this.Text_ComboBox.Name = "Text_ComboBox";
            this.Text_ComboBox.Size = new System.Drawing.Size(121, 21);
            this.Text_ComboBox.TabIndex = 3;
            this.Text_ComboBox.Tag = "Foreground";
            this.Text_ComboBox.SelectedIndexChanged += new System.EventHandler(this.Colors_ComboBox_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(210, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "On click color";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ClickColor_ComboBox
            // 
            this.ClickColor_ComboBox.FormattingEnabled = true;
            this.ClickColor_ComboBox.Location = new System.Drawing.Point(288, 92);
            this.ClickColor_ComboBox.Name = "ClickColor_ComboBox";
            this.ClickColor_ComboBox.Size = new System.Drawing.Size(121, 21);
            this.ClickColor_ComboBox.TabIndex = 3;
            this.ClickColor_ComboBox.Tag = "Click";
            this.ClickColor_ComboBox.SelectedIndexChanged += new System.EventHandler(this.Colors_ComboBox_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(205, 122);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "On hover color";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // HoverColor_ComboBox
            // 
            this.HoverColor_ComboBox.FormattingEnabled = true;
            this.HoverColor_ComboBox.Location = new System.Drawing.Point(288, 119);
            this.HoverColor_ComboBox.Name = "HoverColor_ComboBox";
            this.HoverColor_ComboBox.Size = new System.Drawing.Size(121, 21);
            this.HoverColor_ComboBox.TabIndex = 3;
            this.HoverColor_ComboBox.Tag = "Hover";
            this.HoverColor_ComboBox.SelectedIndexChanged += new System.EventHandler(this.Colors_ComboBox_SelectedIndexChanged);
            // 
            // Reset_Button
            // 
            this.Reset_Button.Location = new System.Drawing.Point(333, 172);
            this.Reset_Button.Name = "Reset_Button";
            this.Reset_Button.Size = new System.Drawing.Size(75, 23);
            this.Reset_Button.TabIndex = 5;
            this.Reset_Button.Text = "Reset";
            this.Reset_Button.UseVisualStyleBackColor = true;
            this.Reset_Button.Click += new System.EventHandler(this.Reset_Button_Click);
            // 
            // superButton1
            // 
            this.superButton1.Endered = false;
            this.superButton1.Location = new System.Drawing.Point(12, 15);
            this.superButton1.Name = "superButton1";
            this.superButton1.OnClkColor = System.Drawing.Color.Wheat;
            this.superButton1.OnHoverColor = System.Drawing.Color.LightSkyBlue;
            this.superButton1.Size = new System.Drawing.Size(180, 180);
            this.superButton1.TabIndex = 0;
            this.superButton1.Text = "superButton1";
            this.superButton1.UseVisualStyleBackColor = false;
            this.superButton1.Click += new System.EventHandler(this.SuperButton1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 201);
            this.Controls.Add(this.Reset_Button);
            this.Controls.Add(this.ButtonText_TextBox);
            this.Controls.Add(this.HoverColor_ComboBox);
            this.Controls.Add(this.ClickColor_ComboBox);
            this.Controls.Add(this.Text_ComboBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.BackColor_ComboBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Sides_UpDown);
            this.Controls.Add(this.superButton1);
            this.Name = "Form1";
            this.Text = "SuperControl";
            ((System.ComponentModel.ISupportInitialize)(this.Sides_UpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private UserControls.SuperButton superButton1;
        private System.Windows.Forms.NumericUpDown Sides_UpDown;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox BackColor_ComboBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ButtonText_TextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox Text_ComboBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox ClickColor_ComboBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox HoverColor_ComboBox;
        private System.Windows.Forms.Button Reset_Button;
    }
}

